Thanks to you of taking an interest to this repo :)

first of all to lauch this code you need to install the pthread elease if you are on windows because 
windows does not  have this library installed already so follow these steps to install you pthread correctly

To install on codeblock follow ;

1.unzip pthreads-w32-2-9-1-releaseinto its own directory

2. go to the directory pthreads-w32-2-9-1-release\Pre-built.2

3. copy all the h files from the pthreads-w32-2-9-1-release\Pre-built.2\include into the MinGW include directory,
 its usualy in C:\Program Files\CodeBlocks\MinGW\include

4.copy all the library files in  pthreads-w32-2-9-1-release\Pre-built.2\lib\x86 into the directory 
C:\Program Files\CodeBlocks\MinGW\lib

5. add the -lphreadGC2 (copy and paste) option into 
Project --> Build -->Options --> Linker Settings --> Other Linker Options of the CodeBlock IDE

6.also make sure that jpeg is written in the section 
Project --> Build -->Options --> Linker Settings --> Link Libraries


To install on Devc++ follow ;
 
For this you just need to install the package pthreads_w32-3.8.0-1aj.DevPack.
This file is in Resources/LIBS in the zip file DevC++ Libs.zip

Close DevC++ and double click on the pthreads_w32-2.8.0-1aj.DevPak  agree to installing (the system should recognize .
DevPak extension and open the package manager).

Once that is successfully installed, quit the package manager and load DevC++, 
which should now work fine for compiling pthreads, 
and should be happy with linking in the libjpeg library that is included in the Prac2 zip file


The project then sould compile correctly ;)